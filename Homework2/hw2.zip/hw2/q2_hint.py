import numpy as np
import matplotlib.pyplot as plt

# Load data
q2_data = np.load('q2_data.npz')
